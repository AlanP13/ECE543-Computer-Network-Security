// CMD Line User Interface

//Run program from Main.java

import java.util.Scanner;
import java.math.*;

public class Display	{
	private boolean cont = true;
	private static Prime prime = new Prime();
	private static RSA rsa = new RSA();

	public void run()	{
		while(cont)	{
			showMenu();
		}
	}

	public void showMenu()	{
		Scanner input = new Scanner(System.in);
		System.out.println("\nAvailable Functions: ");
		System.out.println("primecheck #");
		System.out.println("primegen #ofbits");
		System.out.println("keygen primeOne primeTwo");
		System.out.println("encrypt n e c");
		System.out.println("decrypt n d m");
		System.out.println("\"exit\" to close program");

		System.out.println("\nEnter your function call");
		//String inCmd = input.nextLine()
		String[] function = input.nextLine().split(" ");
		//input.close();

		if(function[0].equalsIgnoreCase("primecheck"))	{
			try	{
				BigInteger num = new BigInteger(function[1]);
				System.out.println(prime.primecheck(num));
			}
			catch(Exception e)	{
				System.out.println("Missing values");
			}
		}
		else if(function[0].equalsIgnoreCase("primegen"))	{
			try	{
				int bits = Integer.parseInt(function[1]);
				prime.primegen(bits);
			}
			catch(Exception e)	{
				System.out.println("Missing values");
			}
		}
		else if(function[0].equalsIgnoreCase("keygen"))	{
			try	{
				rsa.keygen(function[1], function[2]);
			}
			catch(Exception e)	{
				System.out.println("Missing values");
			}
		}
		else if(function[0].equalsIgnoreCase("encrypt"))	{
			try	{
				rsa.encrypt(function[1], function[2], function[3]);
			}
			catch(Exception e)	{
				System.out.println("Missing values");
			}
		}
		else if(function[0].equalsIgnoreCase("decrypt"))	{
			try	{
				rsa.decrypt(function[1], function[2], function[3]);
			}
			catch(Exception e)	{
				System.out.println("Missing values");
			}
		}
		else if(function[0].equalsIgnoreCase("exit"))	{
			cont = false;
		}
		else	{
			System.out.println("Not a supported function");
		}

		/*
		System.out.println("\nContinue? (y/n)");
		String contString = input.next();
		if(contString.equalsIgnoreCase("y") || contString.equalsIgnoreCase("yes"))	{
			cont = true;
		}
		else	{
			cont = false;
		}
		*/
	}
}