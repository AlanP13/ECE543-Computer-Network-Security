// RSA Implementation

//Run program from Main.java

import java.math.*;

public class RSA	{
	Prime prime = new Prime();
	final BigInteger ONE = new BigInteger("1");

	// (e, n) public key
	// (d, n) private key
	// d*e = 1 mod F(n)
	// n=p*q (p,q primes), F(n)=(p-1)(q-1)
	public void keygen(String primeOne, String primeTwo)	{
		BigInteger p = new BigInteger(primeOne);
		BigInteger q = new BigInteger(primeTwo);
		BigInteger n = p.multiply(q);

		//calculate f(n)
		BigInteger f = (p.subtract(ONE)).multiply(q.subtract(ONE));

		//set public key to 2^16+1
		BigInteger e = new BigInteger("65537");

		//set private key
		BigInteger d = e.modInverse(f);


		System.out.println("Public Key: ("+n+","+e+")");
		System.out.println("Private Key: ("+n+","+d+")");
	}

	//Encrypt plaintext using RSA algorithm
	public String encrypt(String nIn, String eIn, String plaintextIn)	{
		BigInteger plaintext = new BigInteger(plaintextIn);
		BigInteger e = new BigInteger(eIn);
		BigInteger n = new BigInteger(nIn);
		BigInteger cipher = new BigInteger("-1");

		cipher = plaintext.pow(e.intValue()).mod(n);
		System.out.println(cipher);

		return cipher.toString();
	}

	//Decrypt ciphertext using RSA algorithm
	public String decrypt(String nIn, String dIn, String ciphertextIn)	{
		BigInteger ciphertext = new BigInteger(ciphertextIn);
		BigInteger d = new BigInteger(dIn);
		BigInteger n = new BigInteger(nIn);
		BigInteger plaintext = new BigInteger("-1");

		plaintext = ciphertext.pow(d.intValue()).mod(n);
		System.out.println(plaintext);

		return plaintext.toString();
	}
}