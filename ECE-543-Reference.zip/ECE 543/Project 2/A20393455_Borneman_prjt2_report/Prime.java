//Prime Number Class

//Run program from Main.java

import java.math.*;

public class Prime	{
	private String num;
	private final int CERTAINTY = 100;
	final BigInteger ONE = new BigInteger("1");

	//Check if bigboi is a prime number using Fermat's method
	public boolean primecheck(BigInteger bigboi)	{
		boolean probPrime = true;
		int testNum = 1;
		//System.out.println("checkPrime: "+bigboi);
		//System.out.println("isProbablePrime: "+bigboi.isProbablePrime(CERTAINTY));

		//an-1 % n = 1
		BigInteger a = new BigInteger("2");
		BigInteger b = new BigInteger("0");
		BigInteger c = new BigInteger("0");

		while(probPrime && testNum<11 && a.intValue()<bigboi.intValue())	{
			b = a.pow(bigboi.subtract(ONE).intValue());
			c = b.mod(bigboi);
			//System.out.println(c.equals(one));
			if(!c.equals(ONE))	{
				probPrime = false;
				//System.out.println("test: "+testNum+", probPrime: "+probPrime+ ", a: "+a+ ", b: "+b+ ", c: "+c);
				//System.out.println("test: "+testNum+", probPrime: "+probPrime+ ", c: "+c);
			}
			else	{
				//System.out.println("test: "+testNum+ ", probPrime: "+probPrime);
			}
			a = a.add(ONE);
			testNum++;
		}

		//System.out.println("primecheck: "+probPrime);
		return probPrime;
	}

	//Create a prime number to a certain number of bits
	public BigInteger primegen(int bits)	{
		//System.out.println("Create prime num of "+bits+" bits");

		int testNum = 1;
		BigInteger newBig = new BigInteger("0");
		newBig = newBig.setBit(bits-1);

		//System.out.println("Test: "+testNum);
		//System.out.println(newBig+", "+primecheck(newBig)+", "+newBig.bitLength());

		while(!primecheck(newBig) && newBig.bitLength()==bits)	{
			testNum++;
			//System.out.println("Test: "+testNum);
			BigInteger random = new BigInteger(String.valueOf((int)(Math.random()*1000)));
			newBig = newBig.add(random);
			if(newBig.bitLength()!=bits)	{
				newBig = new BigInteger("0");
				newBig = newBig.setBit(bits-1);
			}
			//System.out.println(newBig+", "+primecheck(newBig)+", "+newBig.bitLength());
		}

		if(primecheck(newBig))	{
			//System.out.println("primecheck: "+primecheck(newBig)+", Final num: "+newBig);
			System.out.println(newBig);
		}
		else	{
			newBig = new BigInteger("-1");
			System.out.println("No prime numbers of bit length "+ bits);
		}

		return newBig;
	}
}