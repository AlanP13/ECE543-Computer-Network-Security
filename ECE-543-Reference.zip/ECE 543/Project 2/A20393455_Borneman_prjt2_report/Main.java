//RSA Algorithm Project

//Run this file to start the program
//Test cases for each method will be ran first
//The program's menu will then appear with the available functions and their syntax

import java.math.*;

public class Main	{
	private static Prime prime = new Prime();
	private static RSA rsa = new RSA();
	private static Display display = new Display();

	public static void main(String args[])	{
		testPrimecheck();
		testPrimegen();
		testKeygen();
		testEncrypt();
		testDecrypt();

		display.run();
	}

	public static void testPrimecheck()	{
		System.out.println("------ primecheck test cases ------");

		BigInteger bigInt = new BigInteger("32401");
		System.out.println("primecheck "+bigInt);
		System.out.println(prime.primecheck(bigInt));

		bigInt = new BigInteger("3244568");
		System.out.println("primecheck "+bigInt);
		System.out.println(prime.primecheck(bigInt));

		bigInt = new BigInteger("17");
		System.out.println("primecheck "+bigInt);
		System.out.println(prime.primecheck(bigInt));

		bigInt = new BigInteger("344");
		System.out.println("primecheck "+bigInt);
		System.out.println(prime.primecheck(bigInt));

		bigInt = new BigInteger("1026");
		System.out.println("primecheck "+bigInt);
		System.out.println(prime.primecheck(bigInt));

		bigInt = new BigInteger("3079");
		System.out.println("primecheck "+bigInt);
		System.out.println(prime.primecheck(bigInt));

		System.out.println("------ end primecheck test cases ------\n");
	}

	public static void testPrimegen()	{
		System.out.println("------ primegen test cases ------");

		int bits = 5;
		System.out.println("primegen "+bits);
		BigInteger gen = prime.primegen(bits);
		System.out.println("primecheck "+gen);
		System.out.println(prime.primecheck(gen));

		bits = 1024;
		System.out.println("primegen "+bits);
		gen = prime.primegen(bits);
		System.out.println("primecheck "+gen);
		System.out.println(prime.primecheck(gen));

		bits = 3456;
		System.out.println("primegen "+bits);
		gen = prime.primegen(bits);
		System.out.println("primecheck "+gen);
		System.out.println(prime.primecheck(gen));

		System.out.println("------ end primecheck test cases ------\n");
	}

	public static void testKeygen()	{
		System.out.println("------ keygen test cases ------");

		String primeOne = "1019";
		String primeTwo = "1021";
		System.out.println("keygen "+primeOne+" "+primeTwo);
		rsa.keygen(primeOne, primeTwo);

		primeOne = "1093";
		primeTwo = "1097";
		System.out.println("keygen "+primeOne+" "+primeTwo);
		rsa.keygen(primeOne, primeTwo);

		primeOne = "433";
		primeTwo = "499";
		System.out.println("keygen "+primeOne+" "+primeTwo);
		rsa.keygen(primeOne, primeTwo);

		primeOne = "1061";
		primeTwo = "1063";
		System.out.println("keygen "+primeOne+" "+primeTwo);
		rsa.keygen(primeOne, primeTwo);

		primeOne = "1217";
		primeTwo = "1201";
		System.out.println("keygen "+primeOne+" "+primeTwo);
		rsa.keygen(primeOne, primeTwo);

		primeOne = "313";
		primeTwo = "337";
		System.out.println("keygen "+primeOne+" "+primeTwo);
		rsa.keygen(primeOne, primeTwo);

		primeOne = "419";
		primeTwo = "463";
		System.out.println("keygen "+primeOne+" "+primeTwo);
		rsa.keygen(primeOne, primeTwo);

		System.out.println("------ end keygen test cases ------\n");
	}

	public static void testEncrypt()	{
		System.out.println("------ encrypt test cases ------");

		String n = "1040399";
		String e = "7";
		String c = "99";
		System.out.println("encrypt "+n+" "+e+" "+c);
		rsa.encrypt(n, e, c);

		n = "1199021";
		e = "5";
		c = "70";
		System.out.println("encrypt "+n+" "+e+" "+c);
		rsa.encrypt(n, e, c);

		n = "216067";
		e = "5";
		c = "89";
		System.out.println("encrypt "+n+" "+e+" "+c);
		rsa.encrypt(n, e, c);

		n = "1127843";
		e = "7";
		c = "98";
		System.out.println("encrypt "+n+" "+e+" "+c);
		rsa.encrypt(n, e, c);

		n = "1461617";
		e = "7";
		c = "113";
		System.out.println("encrypt "+n+" "+e+" "+c);
		rsa.encrypt(n, e, c);

		n = "105481";
		e = "5";
		c = "105";
		System.out.println("encrypt "+n+" "+e+" "+c);
		rsa.encrypt(n, e, c);

		n = "193997";
		e = "5";
		c = "85";
		System.out.println("encrypt "+n+" "+e+" "+c);
		rsa.encrypt(n, e, c);

		n = "12345678912345678912";
		e = "7";
		c = "45";
		System.out.println("encrypt "+n+" "+e+" "+c);
		rsa.encrypt(n, e, c);

		System.out.println("------ end encrypt test cases ------\n");
	}

	public static void testDecrypt()	{
		System.out.println("------ decrypt test cases ------");

		String n = "1040399";
		String d = "890023";
		String m = "16560";
		System.out.println("decrypt "+n+" "+d+" "+m);
		rsa.encrypt(n, d, m);

		n = "1199021";
		d = "478733";
		m = "901767";
		System.out.println("decrypt "+n+" "+d+" "+m);
		rsa.encrypt(n, d, m);

		n = "216067";
		d = "172109";
		m = "169487";
		System.out.println("decrypt "+n+" "+d+" "+m);
		rsa.encrypt(n, d, m);

		n = "1127843";
		d = "964903";
		m = "539710";
		System.out.println("decrypt "+n+" "+d+" "+m);
		rsa.encrypt(n, d, m);

		n = "1461617";
		d = "1250743";
		m = "93069";
		System.out.println("decrypt "+n+" "+d+" "+m);
		rsa.encrypt(n, d, m);

		n = "105481";
		d = "41933";
		m = "78579";
		System.out.println("decrypt "+n+" "+d+" "+m);
		rsa.encrypt(n, d, m);

		n = "193997";
		d = "154493";
		m = "1583";
		System.out.println("decrypt "+n+" "+d+" "+m);
		rsa.encrypt(n, d, m);

		System.out.println("------ end decrypt test cases ------\n");
	}
}